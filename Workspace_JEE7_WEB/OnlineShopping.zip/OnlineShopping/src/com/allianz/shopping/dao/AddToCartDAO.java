package com.allianz.shopping.dao;

import com.allianz.shopping.model.AddToCart;

public interface AddToCartDAO 
{
	public boolean addToCart(AddToCart add);
}
