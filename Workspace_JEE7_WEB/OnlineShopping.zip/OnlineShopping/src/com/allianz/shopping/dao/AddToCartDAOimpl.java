package com.allianz.shopping.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.allianz.shopping.model.AddToCart;
import com.allianz.shopping.utility.DBUtilityConnection;

public class AddToCartDAOimpl implements AddToCartDAO  
{
	@Override
	public boolean addToCart(AddToCart add)
	{
		Connection con=DBUtilityConnection.getConnection();
		String sql;
		try
		{
			sql="INSERT INTO add_to_cart(Order_ID,productID,quantity,Total_price) values(?,?,?,?)";
			PreparedStatement ps=con.prepareStatement(sql);
			
			ps.setInt(1, add.getOrder_id());
			ps.setInt(2,add.getProduct_id());
			ps.setInt(3, add.getQuantity());
			ps.setFloat(4,add.getTotal());
			int no=ps.executeUpdate();
			if(no>0)
				return true;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return false;
	}
	

}
