package com.interview.pojo;

public class Candidate 
{
	private Integer candidateId;
	private String candidateName;
	private String candidateEmailId;
	private String candidateMobileNo;
	private Double candidateMarks;
	private String candidatePanCardNo;
	private String candidateResume;
	
	
	public Candidate()
	{
		super();
	
	}
	
	public Candidate(Integer candidateId,String candidateName, String candidateEmailId, String candidateMobileNo, Double candidateMarks,
			String candidatePanCardNo, String candidateResumePath)
	{
		super();
		this.candidateId=candidateId;
		this.candidateName = candidateName;
		this.candidateEmailId = candidateEmailId;
		this.candidateMobileNo = candidateMobileNo;
		this.candidateMarks = candidateMarks;
		this.candidatePanCardNo = candidatePanCardNo;
		this.candidateResume = candidateResumePath;
	}
	
	
	
	public Integer getCandidateId()
	{
		return candidateId;
	}

	public void setCandidateId(Integer candidateId) 
	{
		this.candidateId = candidateId;
	}

	public String getCandidateName() 
	{
		return candidateName;
	}
	public void setCandidateName(String candidateName) 
	{
		this.candidateName = candidateName;
	}
	public String getCandidateEmailId() 
	{
		return candidateEmailId;
	}
	public void setCandidateEmailId(String candidateEmailId) 
	{
		this.candidateEmailId = candidateEmailId;
	}
	public String getCandidateMobileNo() 
	{
		return candidateMobileNo;
	}
	public void setCandidateMobileNo(String candidateMobileNo) 
	{
		this.candidateMobileNo = candidateMobileNo;
	}
	public Double getCandidateMarks() 
	{
		return candidateMarks;
	}
	public void setCandidateMarks(Double candidateMarks) 
	{
		this.candidateMarks = candidateMarks;
	}
	public String getCandidatePanCardNo() 
	{
		return candidatePanCardNo;
	}
	public void setCandidatePanCardNo(String candidatePanCardNo) 
	{
		this.candidatePanCardNo = candidatePanCardNo;
	}
	public String getCandidateResumePath() 
	{
		return candidateResume;
	}
	public void setCandidateResumePath(String candidateResumePath) 
	{
		this.candidateResume = candidateResumePath;
	}

	@Override
	public String toString() 
	{
		return "candidate [candidateName=" + candidateName + ", candidateEmailId=" + candidateEmailId
				+ ", candidateMobileNo=" + candidateMobileNo + ", candidateMarks=" + candidateMarks
				+ ", candidatePanCardNo=" + candidatePanCardNo + ", candidateResume=" + candidateResume + "]";
	}
	
	
	
	
}
